# 來源掃描證據契約

來源完整性不得以候選數量、歷史平均或模型宣告判定。每站必須保存可由驗證器重算的掃描證據，並證明已抵達精確 24 小時時間窗的起點，或來源已明確耗盡。

## 每頁必要證據

- 實際請求網址與抓取時間。
- HTTP 狀態；只有成功取得內容才可納入完成鏈。
- 原始 HTML、RSS、API 回應或完整瀏覽器 DOM 快照的本地路徑。
- 原始快照 SHA-256。
- 由該頁解析出的每篇文章標題、單篇網址、發布時間，以及可在原始快照中找到的網址與時間原文。
- 下一頁網址或游標；多頁之間必須形成連續鏈。

候選網址不得等於來源首頁。搜尋頁、分類頁或首頁只能作為掃描頁，不能冒充單篇新聞。

## 合格停止證據

只有以下兩種：

1. `crossed_window_start`：指定頁面內存在發布時間早於或等於 `window_start` 的見證文章。
2. `source_exhausted`：最後一頁沒有下一頁，且原始快照包含來源明確的結束標記。

403、robots、不支援 MIME、登入牆、逾時、解析失敗、缺少時間欄位、動態內容未載入均為當前路由中斷，不是來源不可讀。普通直接讀取失敗時，先由 `recover-news-run` 改用同站 RSS、API、分類頁、站內搜尋或其他合法入口；只有目前工具契約允許時才可再用完整瀏覽器並保存 DOM。瀏覽器不得是排程的必要依賴。所有同站合法非瀏覽器入口均失敗後才可回報來源阻擋，不得由另一來源代替掃描證據。

每篇 `extracted_items` 除既有網址、標題與時間證據外，必須保存可供 hydration 排序與查重的 `summary`、`discovery_priority_reason`、`acquisition_route`；摘要不足時進入單篇文章頁或瀏覽器補齊。此欄位不是事件重要性評分。

## Source row admission ledger

來源掃描完成前，必須將全部時間窗內列物化為 `source-row-admissions.json`。每列使用獨立且穩定的 `row_id`，不得用可能重複的 candidate ID 或 canonical URL 代替 row identity；並保存 source/section、candidate/provisional-group ID、canonical URL、listing timestamp evidence、文章本體 authoritative timestamp evidence、content SHA-256、relevance route 與 model evidence。`scripts/materialize_source_row_admissions.py validate` 必須通過，checkpoint 才能綁定 `source_row_admissions` 並完成 source-scan。

`IMMUTABLE_SOURCE_ROW_IDENTITY_GATE`：`row_id` 只能由 `source_id`、canonical URL、published time 與可選的 source-native stable discriminator 生成；snapshot path、materialized page/item index、排序及之後新增的 fallback rows 都是重建座標，不得改寫既有 ID。同 URL／同時間若確實代表多筆獨立 discovery rows，來源必須保存不同的 immutable `source_row_discriminator`，否則在 hydration 前 fail-closed。

這個 ledger 是 same-run recovery 的唯一 row universe。後續 selection/candidate audit 對每列補寫 terminal `article_dispositions` 時必須沿用相同 row identity；不得由 17 個 threshold events 倒推其餘 raw rows，也不得為補齊 disposition 重跑已完成的 discovery。

## 驗證方式

`scripts/validate_source_scan_evidence.py` 必須重新驗證快照雜湊、翻頁鏈、停止證據，並從快照中的全部文章重算時間窗清單。重算結果必須與 `ranked_items` 及 `within_window_count` 完全一致。

不設任何最低候選數量，也不以 C、D、E 數量作為成功條件。即使某站只有零則，只要來源耗盡證據成立，仍可通過；反之，抓到很多文章但未抵達時間邊界，仍不得通過。
