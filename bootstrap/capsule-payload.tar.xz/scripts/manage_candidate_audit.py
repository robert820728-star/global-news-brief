#!/usr/bin/env python3
"""Validate and retain the rolling candidate/source audit."""

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

import validate_source_scan_evidence

GRADE_ORDER = {
    "E": 0, "D": 1, "C-": 2, "C": 3, "C+": 4,
    "B-": 5, "B": 6, "B+": 7, "A-": 8, "A": 9, "A+": 10,
    "S-": 11, "S": 12, "S+": 13, "SS": 14,
}
RANKING_DIMENSION_NAMES = (
    "public_impact",
    "geographic_or_population_scope",
    "urgency_and_safety",
    "structural_or_policy_significance",
    "material_new_development",
    "core_section_relevance",
)
SOURCE_COVERAGE_FIELDS = {
    "source_id", "scan_status", "coverage_complete", "coverage_status",
    "coverage_reason", "missing_segments", "missing_date_variants",
    "within_window_count", "ranked_count", "ranked_items",
    "selected_for_pool_count", "selected_item_urls", "discovery_ranking_completed",
    "discovery_ranking_method", "failure_reason", "scan_window_start", "scan_window_end",
    "scan_evidence_path",
}
INTEGRATED_GRADING_PRINCIPLES = {
    "combined_evidence_no_single_dimension_hard_cap": True,
    "importance_severity_is_public_impact": True,
    "scope_is_one_weighted_dimension": True,
}
POLICY_STAGES = {
    "not_applicable", "rumor", "consideration", "proposal", "draft",
    "introduced", "passed", "signed", "effective", "implemented",
    "measurable_effect",
}
CONSEQUENCE_CLASSES = {"realized", "ongoing", "potential", "speculative"}
LOCAL_DISASTER_SPECIAL_TRIGGERS = {
    "monitored_region_conflict_escalation_risk",
    "extreme_missing_serious_injury_or_evacuation",
    "major_public_system_disruption",
    "rapidly_expanding_disaster",
    "cross_regional_direct_impact",
    "multinational_direct_impact",
    "rare_disaster_mechanism",
    "regulatory_failure_or_systemic_risk",
    "mass_housing_or_critical_infrastructure_loss",
    "historic_extreme_scale",
    "special_security_or_public_health",
    "other_verified_special_significance",
}
POLICY_GOVERNANCE_TRIGGERS = {
    "attributable_policy_report",
    "official_consideration",
    "official_legal_interpretation",
    "investigation_or_enforcement_referral",
    "binding_or_operational_compliance_request",
    "platform_or_operator_action",
    "multi_agency_coordination",
    "precedent_or_spillover_risk",
    "public_reaction",
}
POLICY_GOVERNANCE_OFFICIAL_ACTION_TRIGGERS = {
    "official_legal_interpretation",
    "investigation_or_enforcement_referral",
    "binding_or_operational_compliance_request",
}
POLICY_GOVERNANCE_SCOPE_TRIGGERS = {
    "multi_agency_coordination",
    "precedent_or_spillover_risk",
}
POLICY_SCORE_ALIGNMENT_FIELDS = {
    "public_impact_alignment",
    "scope_alignment",
    "structural_alignment",
    "window_alignment",
}
TEMPLATE_GRADE_REASONS = {
    "依公共影響評級",
    "具有公共影響",
    "值得持續追蹤",
    "具有公共價值",
    "事件具可驗證的政策、安全或民生影響，值得持續追蹤。",
    "事件明確影響公共安全、治理、經濟或區域關係，但範圍仍有限。",
}
REASON_CODES = {
    "selected_threshold_met", "c_minus_reserve",
    "outside_time_window", "duplicate_merged", "continuation_no_material_change",
    "below_public_value_threshold", "unreliable_or_unverified",
    "superseded_by_later_update", "wrong_scope", "processing_failure",
    "search_recall_failure",
}

MATERIAL_UPDATE_TYPES = {
    "new_event", "official_confirmation", "casualty_or_impact_revision",
    "policy_or_legal_change", "operational_or_status_change",
    "material_escalation_or_deescalation", "other_verified_material_change",
    "ongoing_verified_current_impact",
}


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def parse_datetime(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def grade_from_importance_score(score, ranking=None):
    """Map a verified six-dimension total to the final SS-E grade."""
    if not isinstance(score, (int, float)) or isinstance(score, bool) or not 0 <= score <= 100:
        raise ValueError("importance score must be a number from 0 through 100")
    contract = ranking or repository_ranking()
    bands = contract.get("grade_minimum_scores", {})
    if set(bands) != set(GRADE_ORDER):
        raise ValueError("grade_minimum_scores must define every SS-E grade")
    for grade, minimum in sorted(
        bands.items(), key=lambda item: item[1], reverse=True
    ):
        if score >= minimum:
            return grade
    raise AssertionError("unreachable score band")


def grade_meets_threshold(grade, threshold, ranking=None):
    """Compare grade labels using the configured score-band authority."""
    contract = ranking or repository_ranking()
    bands = contract.get("grade_minimum_scores", {})
    if grade not in bands or threshold not in bands:
        return False
    return bands[grade] >= bands[threshold]


def ranking_contract(ranking):
    """Return a validated normalized-dimension ranking contract."""
    if not isinstance(ranking, dict) or ranking.get("method") != "public_value_v2":
        raise ValueError("ranking method must be public_value_v2")
    dimensions = ranking.get("dimensions")
    if not isinstance(dimensions, dict) or set(dimensions) != set(RANKING_DIMENSION_NAMES):
        raise ValueError("ranking must define the six public_value_v2 dimensions")
    for name, contract in dimensions.items():
        if not isinstance(contract, dict):
            raise ValueError(f"{name} ranking contract must be an object")
        if contract.get("minimum") != 0 or contract.get("maximum") != 100:
            raise ValueError(f"{name} must use the normalized 0-100 scale")
        weight = contract.get("weight_percent")
        if not isinstance(weight, (int, float)) or isinstance(weight, bool) or weight <= 0:
            raise ValueError(f"{name} weight_percent must be positive")
    if abs(sum(item["weight_percent"] for item in dimensions.values()) - 100) > 0.01:
        raise ValueError("public_value_v2 weights must total 100")
    step = ranking.get("allowed_score_step")
    if not isinstance(step, int) or isinstance(step, bool) or step <= 0:
        raise ValueError("allowed_score_step must be a positive integer")
    grade_bands = ranking.get("grade_minimum_scores")
    if not isinstance(grade_bands, dict) or set(grade_bands) != set(GRADE_ORDER):
        raise ValueError("grade_minimum_scores must define every SS-E grade")
    ordered_minimums = [grade_bands[grade] for grade in GRADE_ORDER]
    if (
        any(not isinstance(value, (int, float)) or isinstance(value, bool) or not 0 <= value <= 100
            for value in ordered_minimums)
        or ordered_minimums != sorted(ordered_minimums)
    ):
        raise ValueError("grade_minimum_scores must increase from E through SS")
    casualty_floors = ranking.get("casualty_public_impact_floors")
    if not isinstance(casualty_floors, dict) or not casualty_floors:
        raise ValueError("casualty_public_impact_floors must be configured")
    if any(
        not isinstance(value, (int, float)) or isinstance(value, bool) or not 0 <= value <= 100
        for value in casualty_floors.values()
    ):
        raise ValueError("casualty public-impact floors must be 0-100 numbers")
    urgency_anchors = ranking.get("dimension_anchors", {}).get("urgency_and_safety")
    if not isinstance(urgency_anchors, list) or not urgency_anchors:
        raise ValueError("urgency_and_safety anchors must be configured")
    urgency_scores = [item.get("score") for item in urgency_anchors if isinstance(item, dict)]
    if (
        len(urgency_scores) != len(urgency_anchors)
        or urgency_scores != sorted(set(urgency_scores))
        or urgency_scores[0] != 0
        or urgency_scores[-1] != 100
    ):
        raise ValueError("urgency_and_safety anchors must uniquely span 0 through 100")
    confidence = ranking.get("confidence_bands")
    if not isinstance(confidence, dict) or set(confidence) != {"high", "medium", "low"}:
        raise ValueError("confidence_bands must define high, medium, and low")
    ranges = sorted((bounds[0], bounds[1], name) for name, bounds in confidence.items())
    if (
        any(
            not isinstance(low, int) or not isinstance(high, int) or low > high
            for low, high, _name in ranges
        )
        or ranges[0][0] != 0
        or ranges[-1][1] != 100
        or any(left[1] + 1 != right[0] for left, right in zip(ranges, ranges[1:]))
    ):
        raise ValueError("confidence_bands must continuously cover 0 through 100")
    return ranking


def weighted_score(breakdown, ranking):
    """Calculate a public-value score from normalized dimensions and config weights."""
    contract = ranking_contract(ranking)
    dimensions = contract["dimensions"]
    if not isinstance(breakdown, dict) or set(breakdown) != set(dimensions):
        raise ValueError("importance breakdown must contain the six configured dimensions")
    step = contract["allowed_score_step"]
    total = 0.0
    for name, settings in dimensions.items():
        value = breakdown[name]
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise ValueError(f"{name} must be numeric")
        if not settings["minimum"] <= value <= settings["maximum"]:
            raise ValueError(f"{name} must be between 0 and 100")
        if abs(value / step - round(value / step)) > 1e-9:
            raise ValueError(f"{name} must use {step}-point score steps")
        total += value * settings["weight_percent"] / 100
    return round(total, 2)


def repository_ranking():
    """Load the sole active scoring contract from news-source-pool.json."""
    return load(Path(__file__).resolve().parents[1] / "news-source-pool.json")["ranking"]


def confidence_band(score, ranking=None):
    """Map evidence maturity independently from public-value importance."""
    if not isinstance(score, int) or isinstance(score, bool) or not 0 <= score <= 100:
        raise ValueError("evidence confidence must be an integer from 0 through 100")
    contract = ranking_contract(ranking or repository_ranking())
    for band, (minimum, maximum) in contract["confidence_bands"].items():
        if minimum <= score <= maximum:
            return band
    raise AssertionError("unreachable confidence band")


def validate_v2_candidate(candidate, ranking, label):
    """Bind every V2 dimension score to eligible facts before a grade is trusted."""
    errors = []
    try:
        contract = ranking_contract(ranking)
    except ValueError as error:
        return [label + f" ranking contract 無效：{error}"]
    dimensions = contract["dimensions"]
    dimension_names = set(dimensions)
    threshold = contract.get("high_score_threshold", 70)
    delta_threshold = contract.get("material_delta_threshold", 70)
    reuse_threshold = contract.get("cross_dimension_reuse_threshold", 3)

    if candidate.get("scoring_method") != "public_value_v2":
        errors.append(label + ".scoring_method 必須是 public_value_v2")
    breakdown = candidate.get("importance_breakdown")
    calculated = None
    try:
        calculated = weighted_score(breakdown, contract)
    except ValueError as error:
        errors.append(label + f" importance_breakdown 無效：{error}")
    for field in ("weighted_score", "importance_score"):
        value = candidate.get(field)
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not 0 <= value <= 100:
            errors.append(label + f" {field} 必須介於 0–100")
        elif calculated is not None and abs(value - calculated) > 0.01:
            errors.append(label + f" {field} 必須等於加權分數 {calculated:g}")
    score = candidate.get("importance_score")
    if isinstance(score, (int, float)) and not isinstance(score, bool):
        if candidate.get("provisional_grade") != grade_from_importance_score(score, contract):
            errors.append(label + " provisional_grade 必須由 importance_score 的固定級距換算")

    facts = candidate.get("evidence_facts")
    fact_index = {}
    if not isinstance(facts, list) or not facts:
        errors.append(label + ".evidence_facts 必須是非空證據事實陣列")
        facts = []
    for index, fact in enumerate(facts, 1):
        fact_label = f"{label}.evidence_facts[{index}]"
        if not isinstance(fact, dict):
            errors.append(fact_label + " 必須是物件")
            continue
        fact_id = fact.get("fact_id")
        if not isinstance(fact_id, str) or not fact_id.strip():
            errors.append(fact_label + ".fact_id 不得為空")
            continue
        if fact_id in fact_index:
            errors.append(label + f".evidence_facts 的 fact_id 重複：{fact_id}")
        fact_index[fact_id] = fact
        if fact.get("consequence_class") not in CONSEQUENCE_CLASSES:
            errors.append(fact_label + ".consequence_class 無效")
        confidence = fact.get("confidence")
        if not isinstance(confidence, int) or isinstance(confidence, bool) or not 0 <= confidence <= 100:
            errors.append(fact_label + ".confidence 必須為 0–100 整數")
        if not isinstance(fact.get("source_urls"), list) or not fact["source_urls"]:
            errors.append(fact_label + ".source_urls 必須是非空陣列")

    consequence = candidate.get("consequence_evidence")
    membership = {}
    if not isinstance(consequence, dict) or set(consequence) != CONSEQUENCE_CLASSES:
        errors.append(label + ".consequence_evidence 必須分開 realized/ongoing/potential/speculative")
        consequence = {}
    for consequence_class in CONSEQUENCE_CLASSES:
        fact_ids = consequence.get(consequence_class, [])
        if not isinstance(fact_ids, list) or len(fact_ids) != len(set(fact_ids)):
            errors.append(label + f".consequence_evidence.{consequence_class} 必須是唯一 fact_id 陣列")
            continue
        for fact_id in fact_ids:
            if fact_id not in fact_index:
                errors.append(label + f".consequence_evidence 引用未知 fact_id：{fact_id}")
            elif fact_index[fact_id].get("consequence_class") != consequence_class:
                errors.append(label + f".consequence_evidence 的 {fact_id} 分類不一致")
            if fact_id in membership:
                errors.append(label + f".consequence_evidence 的 {fact_id} 不得跨類重複")
            membership[fact_id] = consequence_class
    if set(fact_index) != set(membership):
        errors.append(label + ".consequence_evidence 必須逐筆分類全部 evidence_facts")

    evidence = candidate.get("dimension_evidence")
    reuse = Counter()
    if not isinstance(evidence, dict) or set(evidence) != dimension_names:
        errors.append(label + ".dimension_evidence 必須逐項引用六個維度的 fact_id")
        evidence = {}
    eligibility = contract.get("dimension_fact_eligibility", {})
    for dimension in dimensions:
        fact_ids = evidence.get(dimension)
        score_value = breakdown.get(dimension) if isinstance(breakdown, dict) else None
        if (
            not isinstance(fact_ids, list)
            or len(fact_ids) != len(set(fact_ids))
            or (isinstance(score_value, (int, float)) and score_value > 0 and not fact_ids)
        ):
            errors.append(label + f".dimension_evidence.{dimension} 正分必須引用唯一 fact_id 陣列")
            continue
        allowed_classes = set(eligibility.get(dimension, ("realized", "ongoing")))
        for fact_id in fact_ids:
            fact = fact_index.get(fact_id)
            if fact is None:
                errors.append(label + f".dimension_evidence.{dimension} 引用未知 fact_id：{fact_id}")
                continue
            reuse[fact_id] += 1
            consequence_class = fact.get("consequence_class")
            if consequence_class == "speculative":
                errors.append(label + f".dimension_evidence.{dimension} 不得引用 speculative fact {fact_id}")
            elif consequence_class not in allowed_classes:
                errors.append(label + f".dimension_evidence.{dimension} 不得引用 {consequence_class} fact {fact_id}")
            elif consequence_class == "potential" and dimension == "structural_or_policy_significance":
                if fact.get("confidence", 0) < 80 or not str(fact.get("institutional_mechanism") or "").strip():
                    errors.append(label + f".dimension_evidence.{dimension} 的 potential fact 必須高可信且有制度機制")

    midpoint_rationales = candidate.get("midpoint_rationales")
    if not isinstance(midpoint_rationales, list):
        errors.append(label + ".midpoint_rationales 必須是陣列")
        midpoint_rationales = []
    midpoint_by_dimension = {
        item.get("dimension"): item
        for item in midpoint_rationales if isinstance(item, dict)
    }
    if isinstance(breakdown, dict):
        for dimension, value in breakdown.items():
            if not isinstance(value, (int, float)) or value % 10 != 5:
                continue
            rationale = midpoint_by_dimension.get(dimension)
            lower = int(value // 10 * 10)
            upper = lower + 10
            if (
                not rationale
                or rationale.get("lower_anchor") != lower
                or rationale.get("upper_anchor") != upper
                or not str(rationale.get("rationale") or "").strip()
                or not set(rationale.get("supporting_facts", [])).issubset(
                    set(evidence.get(dimension, []))
                )
            ):
                errors.append(
                    label + f".midpoint_rationale 缺少 {dimension}={value:g} "
                    f"介於 {lower} 與 {upper} 的證據理由"
                )

    rationales = candidate.get("cross_dimension_rationales")
    if not isinstance(rationales, list):
        errors.append(label + ".cross_dimension_rationales 必須是陣列")
        rationales = []
    rationale_by_fact = {
        item.get("fact_id"): item for item in rationales if isinstance(item, dict)
    }
    for fact_id, count in reuse.items():
        if count >= reuse_threshold:
            rationale = rationale_by_fact.get(fact_id)
            if not rationale or not str(rationale.get("rationale") or "").strip():
                errors.append(label + f".cross_dimension_rationales 缺少重複支撐 {count} 個維度的 {fact_id}")
            elif set(rationale.get("dimensions", [])) != {
                name for name, ids in evidence.items() if isinstance(ids, list) and fact_id in ids
            }:
                errors.append(label + f".cross_dimension_rationales 的 {fact_id} 維度清單不一致")

    delta_facts = candidate.get("delta_facts")
    if not isinstance(delta_facts, list):
        errors.append(label + ".delta_facts 必須是陣列")
        delta_facts = []
    update_score = breakdown.get("material_new_development") if isinstance(breakdown, dict) else None
    if isinstance(update_score, (int, float)) and update_score >= delta_threshold and not delta_facts:
        errors.append(label + f" material_new_development>={delta_threshold:g} 必須提供 delta_fact")
    for delta in delta_facts:
        if not isinstance(delta, dict) or delta.get("fact_id") not in fact_index:
            errors.append(label + ".delta_facts 必須引用已存在的 fact_id")

    challenges = candidate.get("high_score_challenges")
    if not isinstance(challenges, list):
        errors.append(label + ".high_score_challenges 必須是陣列")
        challenges = []
    challenge_by_dimension = {
        item.get("dimension"): item for item in challenges if isinstance(item, dict)
    }
    if isinstance(breakdown, dict):
        for dimension, value in breakdown.items():
            if isinstance(value, (int, float)) and value >= threshold:
                challenge = challenge_by_dimension.get(dimension)
                if not challenge or challenge.get("outcome") != "sustained":
                    errors.append(label + f".high_score_challenge 缺少 {dimension}>={threshold:g} 的 sustained 反向審查")
                elif not set(challenge.get("supporting_facts", [])).issubset(fact_index):
                    errors.append(label + f".high_score_challenge.{dimension} 引用未知 fact_id")
    if isinstance(score, (int, float)) and score >= threshold:
        overall = candidate.get("overall_high_score_challenge")
        if not isinstance(overall, dict) or overall.get("dimension") != "overall" or overall.get("outcome") != "sustained":
            errors.append(label + f".overall_high_score_challenge 是總分>={threshold:g} 的必要反向審查")
        elif not set(overall.get("supporting_facts", [])).issubset(fact_index):
            errors.append(label + ".overall_high_score_challenge 引用未知 fact_id")

    policy_stage = candidate.get("policy_stage")
    if policy_stage not in POLICY_STAGES:
        errors.append(label + ".policy_stage 無效")
    policy_review = candidate.get("grading_evidence", {}).get("policy_governance_review")
    if policy_stage != "not_applicable" and isinstance(policy_review, dict) and policy_review.get("applies") is not True:
        errors.append(label + ".policy_stage 為政策事件時 policy_governance_review.applies 必須為 true")

    confidence = candidate.get("evidence_confidence")
    try:
        expected_band = confidence_band(confidence, contract)
    except ValueError as error:
        errors.append(label + f".evidence_confidence 無效：{error}")
    else:
        if candidate.get("confidence_band") != expected_band:
            errors.append(label + f".confidence_band 必須是 {expected_band}，且不得改變 importance_score")

    grade_status = candidate.get("grade_status")
    if grade_status not in {"unscored", "provisional", "validated"}:
        errors.append(label + ".grade_status 無效")
    if candidate.get("decision") in {"selected", "merged"} and grade_status != "validated":
        errors.append(label + " 進入 Reader 的候選必須 grade_status=validated")
    return errors


COMPACT_HISTORICAL_REQUIRED_FIELDS = {
    "candidate_id", "dedup_key", "event_date", "section", "title",
    "scoring_method", "importance_breakdown", "weighted_score",
    "importance_score", "dimension_evidence", "consequence_evidence",
    "evidence_facts", "policy_stage", "delta_facts",
    "high_score_challenges", "overall_high_score_challenge",
    "cross_dimension_rationales", "midpoint_rationales",
    "evidence_confidence", "confidence_band", "grade_status",
    "provisional_grade", "decision", "reason", "source_ids",
    "selected_event_id", "continuity",
}


def is_compact_historical_candidate(candidate):
    """Recognize the documented mobile continuity-cache profile, never a latest run."""
    return (
        isinstance(candidate, dict)
        and candidate.get("scoring_method") == "public_value_v2"
        and "event_date" in candidate
        and all(
            field not in candidate
            for field in (
                "grading_evidence", "source_audit", "candidate_urls",
                "reason_code", "grade_reason",
            )
        )
    )


def validate_compact_historical_candidate(candidate, ranking, valid_source_ids, label):
    """Validate compact history without inventing evidence omitted by mobile-native."""
    errors = []
    missing = sorted(COMPACT_HISTORICAL_REQUIRED_FIELDS - set(candidate))
    if missing:
        errors.append(label + " compact historical candidate 缺少：" + ", ".join(missing))
        return errors
    for field in ("candidate_id", "dedup_key", "title", "section", "reason"):
        if not isinstance(candidate.get(field), str) or not candidate[field].strip():
            errors.append(label + f".{field} 不得為空")
    try:
        datetime.strptime(candidate["event_date"], "%Y-%m-%d")
    except (TypeError, ValueError):
        errors.append(label + ".event_date 必須是 ISO 日期")
    errors.extend(validate_v2_candidate(candidate, ranking, label))
    source_ids = candidate.get("source_ids")
    if not isinstance(source_ids, list) or not source_ids:
        errors.append(label + " 缺少來源池追溯")
    elif any(source_id not in valid_source_ids for source_id in source_ids):
        errors.append(label + " 引用未定義的 discovery 來源")
    grade = candidate.get("provisional_grade")
    decision = candidate.get("decision")
    if grade_meets_threshold(grade, "C", ranking) and decision not in {"selected", "merged"}:
        errors.append(label + " C 以上歷史候選必須保留其 selected／merged 映射")
    if grade_meets_threshold(grade, "C", ranking) and (
        not isinstance(candidate.get("selected_event_id"), str)
        or not candidate["selected_event_id"].strip()
    ):
        errors.append(label + " C 以上歷史候選必須保留 selected_event_id")
    if not grade_meets_threshold(grade, "C", ranking) and decision == "selected":
        errors.append(label + " C-／D／E 不得入選")
    if not isinstance(candidate.get("continuity"), dict):
        errors.append(label + ".continuity 必須是物件")
    return errors


def validate_policy_governance_review(
    review, importance_score, label, policy_stage="not_applicable", ranking=None
):
    """Require event identity and institutional evidence to agree with scoring."""
    errors = []
    if not isinstance(review, dict):
        return [label + " 最新一輪缺少 policy_governance_review"]
    applies = review.get("applies")
    if not isinstance(applies, bool):
        return [label + " policy_governance_review.applies 必須是布林值"]
    if not applies:
        return errors

    required_fields = {
        "triggered_by", "legal_basis", "official_actions",
        "direct_operational_effects", "affected_actor_classes",
        "cross_agency_effects", "precedent_or_spillover_scope",
        "window_material_effects", "evidence_urls",
        "unverified_allegations", "unverified_allegations_separated",
        "score_consistency_review",
    }
    missing = sorted(required_fields - set(review))
    if missing:
        errors.append(label + " policy_governance_review 缺少：" + ", ".join(missing))

    triggered_by = review.get("triggered_by")
    if not isinstance(triggered_by, list) or not triggered_by:
        errors.append(label + " policy_governance_review.triggered_by 必須是非空陣列")
        triggered_by = []
    else:
        invalid_triggers = [
            trigger for trigger in triggered_by
            if not isinstance(trigger, str) or trigger not in POLICY_GOVERNANCE_TRIGGERS
        ]
        if invalid_triggers:
            errors.append(
                label + " policy_governance_review.triggered_by 無效："
                + ", ".join(map(str, invalid_triggers))
            )
        if all(isinstance(trigger, str) for trigger in triggered_by) and len(triggered_by) != len(set(triggered_by)):
            errors.append(label + " policy_governance_review.triggered_by 不得重複")

    required_nonempty_lists = ["evidence_urls"]
    if policy_stage == "consideration":
        required_nonempty_lists.append("official_actions")
    elif policy_stage in {"proposal", "draft"}:
        required_nonempty_lists.extend(
            ["official_actions", "affected_actor_classes"]
        )
    elif policy_stage in {"introduced", "passed", "signed"}:
        required_nonempty_lists.extend(
            ["legal_basis", "official_actions", "affected_actor_classes"]
        )
    elif policy_stage in {"effective", "implemented", "measurable_effect"}:
        required_nonempty_lists.extend(
            ["legal_basis", "official_actions", "affected_actor_classes", "window_material_effects"]
        )
    for field in required_nonempty_lists:
        value = review.get(field)
        if not isinstance(value, list) or not value or any(
            not isinstance(item, str) or not item.strip() for item in value
        ):
            errors.append(label + f" policy_governance_review.{field} 必須是非空具體文字陣列")
    for field in (
        "legal_basis", "official_actions", "affected_actor_classes",
        "window_material_effects", "direct_operational_effects", "cross_agency_effects",
        "precedent_or_spillover_scope", "unverified_allegations",
    ):
        value = review.get(field)
        if not isinstance(value, list) or any(
            not isinstance(item, str) or not item.strip() for item in value
        ):
            errors.append(label + f" policy_governance_review.{field} 必須是具體文字陣列")
    if "multi_agency_coordination" in triggered_by and not review.get("cross_agency_effects"):
        errors.append(label + " multi_agency_coordination 必須有 cross_agency_effects 證據")
    if "precedent_or_spillover_risk" in triggered_by and not review.get("precedent_or_spillover_scope"):
        errors.append(label + " precedent_or_spillover_risk 必須有 precedent_or_spillover_scope 證據")
    evidence_urls = review.get("evidence_urls")
    if isinstance(evidence_urls, list) and any(
        isinstance(url, str) and not url.startswith(("https://", "http://"))
        for url in evidence_urls
    ):
        errors.append(label + " policy_governance_review.evidence_urls 必須是 HTTP(S) 網址")

    allegations = review.get("unverified_allegations")
    separated = review.get("unverified_allegations_separated")
    if not isinstance(separated, bool):
        errors.append(label + " unverified_allegations_separated 必須是布林值")
    elif isinstance(allegations, list) and allegations and not separated:
        errors.append(label + " unverified_allegations 必須與已證實事件身分及六項評分分離")

    consistency = review.get("score_consistency_review")
    if not isinstance(consistency, dict):
        errors.append(label + " policy_governance_review 缺少 score_consistency_review")
        consistency = {}
    required_consistency = POLICY_SCORE_ALIGNMENT_FIELDS | {
        "contradiction_reasons", "why_not_b", "review_outcome",
    }
    missing_consistency = sorted(required_consistency - set(consistency))
    if missing_consistency:
        errors.append(
            label + " score_consistency_review 缺少：" + ", ".join(missing_consistency)
        )
    alignment_values = [consistency.get(field) for field in POLICY_SCORE_ALIGNMENT_FIELDS]
    invalid_alignments = [
        field for field in POLICY_SCORE_ALIGNMENT_FIELDS
        if consistency.get(field) not in {"consistent", "contradiction", "unresolved"}
    ]
    if invalid_alignments:
        errors.append(label + " score_consistency_review 對齊狀態無效：" + ", ".join(sorted(invalid_alignments)))
    contradiction_reasons = consistency.get("contradiction_reasons")
    if not isinstance(contradiction_reasons, list) or any(
        not isinstance(item, str) or not item.strip() for item in contradiction_reasons
    ):
        errors.append(label + " score_consistency_review.contradiction_reasons 必須是具體文字陣列")
    if any(value in {"contradiction", "unresolved"} for value in alignment_values) or consistency.get("review_outcome") != "consistent":
        errors.append(label + " 制度證據與六項評分矛盾或未解，必須退回重審並修正事件身分或重新評分")

    trigger_set = {trigger for trigger in triggered_by if isinstance(trigger, str)}
    strong_profile = (
        bool(trigger_set & POLICY_GOVERNANCE_OFFICIAL_ACTION_TRIGGERS)
        and "platform_or_operator_action" in trigger_set
        and bool(trigger_set & POLICY_GOVERNANCE_SCOPE_TRIGGERS)
    )
    if (
        strong_profile
        and isinstance(importance_score, (int, float))
        and not isinstance(importance_score, bool)
        and importance_score < (ranking or repository_ranking())["grade_minimum_scores"]["B"]
        and (
            not isinstance(consistency.get("why_not_b"), str)
            or not consistency["why_not_b"].strip()
        )
    ):
        errors.append(label + " 強制度治理證據低於 B 時必須提供具體 why_not_b 挑戰理由")
    return errors


def grade_from_importance_breakdown(breakdown, ranking=None):
    """Derive a grade from the combined six-dimension evidence score."""
    contract = ranking or repository_ranking()
    return grade_from_importance_score(weighted_score(breakdown, contract), contract)


def public_impact_floor_from_confirmed_deaths(confirmed_deaths, ranking=None):
    """Return the public-impact floor contributed by conservative confirmed deaths."""
    if not isinstance(confirmed_deaths, int) or isinstance(confirmed_deaths, bool) or confirmed_deaths < 0:
        raise ValueError("confirmed deaths must be a nonnegative integer")
    if confirmed_deaths == 0:
        return 0
    floors = (ranking or repository_ranking())["casualty_public_impact_floors"]
    for label, floor in floors.items():
        if label.endswith("+"):
            if confirmed_deaths >= int(label[:-1]):
                return floor
            continue
        lower_text, upper_text = label.split("-", 1)
        if int(lower_text) <= confirmed_deaths <= int(upper_text):
            return floor
    raise ValueError("confirmed deaths are not covered by configured casualty bands")


def fourteen_day_completeness_errors(data):
    """Report whether a durable audit actually covers its rolling 14-day window."""
    runs = data.get("runs")
    if not isinstance(runs, list) or not runs:
        return ["十四天稽核為空，不能宣告十四天清單已完成"]
    try:
        latest_end = max(parse_datetime(item["window_end"]) for item in runs)
        earliest_start = min(parse_datetime(item["window_start"]) for item in runs)
    except (KeyError, TypeError, ValueError):
        return ["十四天稽核缺少可解析的 window_start 或 window_end"]
    required_start = latest_end - timedelta(days=14)
    if earliest_start > required_start:
        return [
            "十四天稽核未覆蓋完整滾動視窗："
            f"最早 {earliest_start.isoformat()}，應不晚於 {required_start.isoformat()}"
        ]
    return []


def validate(data, source_pool=None, require_fourteen_day_complete=False):
    errors = []
    if data.get("schema_version") != "1.2.0":
        errors.append("schema_version 必須是 1.2.0")
    if data.get("retention_days") != 14:
        errors.append("retention_days 必須固定為 14")

    source_scan_evidence_required = False
    source_by_id = {}
    discovery_source_ids = []
    primary_aggregator_ids = []
    minimum_ready_discovery_sources = 0
    all_configured_source_ids = set()
    if source_pool is None:
        source_pool = load(Path(__file__).resolve().parents[1] / "news-source-pool.json")
    ranking_dimensions = {}
    ranking = {}
    if source_pool:
        discovery_source_ids = [
            item["source_id"] for item in source_pool.get("discovery_sources", [])
        ]
        primary_aggregator_ids = [
            item["source_id"]
            for item in source_pool.get("discovery_sources", [])
            if item.get("role") == "primary_aggregator"
        ]
        minimum_ready_discovery_sources = int(
            source_pool.get("discovery_policy", {}).get(
                "minimum_ready_sources", len(discovery_source_ids)
            )
        )
        all_configured_source_ids = set(discovery_source_ids)
        source_scan_evidence_required = source_pool.get("source_scan_evidence_required") is True
        source_by_id = {
            item["source_id"]: item
            for item in source_pool.get("discovery_sources", [])
        }
        if not discovery_source_ids or len(set(discovery_source_ids)) != len(discovery_source_ids):
            errors.append("news-source-pool.json 必須定義至少一個且全部唯一的 discovery source")
        if not source_scan_evidence_required:
            errors.append("news-source-pool.json 必須鎖定 source_scan_evidence_required=true")
        ranking = source_pool.get("ranking", {})
        ranking_dimensions = ranking.get("dimensions", {})
        conflict_rule = source_pool.get("conflict_evidence_policy", {})
        if conflict_rule.get("routine_incident_requires_current_consequence_review") is not True:
            errors.append("news-source-pool.json 必須要求衝突事件依本輪後果重新審查")
        if conflict_rule.get("material_change_requires_regrading") is not True:
            errors.append("news-source-pool.json 必須要求衝突出現實質變化時重新評級")
        if conflict_rule.get("parent_conflict_grade_inheritance_forbidden") is not True:
            errors.append("news-source-pool.json 必須禁止沿用母衝突等級")
        if conflict_rule.get("source_count_must_not_change_grade") is not True:
            errors.append("news-source-pool.json 必須禁止來源數量改變評級")
        try:
            ranking_contract(ranking)
        except ValueError as error:
            errors.append(f"news-source-pool.json 的 public_value_v2 設定無效：{error}")
        if ranking.get("grading_principles") != INTEGRATED_GRADING_PRINCIPLES:
            errors.append("news-source-pool.json 必須鎖定六項綜合評級且不得設單項硬上限")

    runs = data.get("runs", [])
    for run_index, run in enumerate(runs, 1):
        run_label = f"runs[{run_index}]"
        is_latest_run = run_index == len(runs)
        coverage = run.get("source_coverage", [])
        if not isinstance(coverage, list):
            errors.append(run_label + ".source_coverage 必須是陣列")
            coverage = []
        coverage_ids = [item.get("source_id") for item in coverage if isinstance(item, dict)]
        completed_coverage_count = sum(
            isinstance(item, dict) and item.get("scan_status") == "completed"
            for item in coverage
        )
        discovery_coverage = (
            bool(discovery_source_ids)
            and set(coverage_ids) == set(discovery_source_ids)
            and len(coverage_ids) == len(set(coverage_ids))
            and completed_coverage_count >= minimum_ready_discovery_sources
        )
        if source_pool is not None and is_latest_run and not discovery_coverage:
            errors.append(
                run_label
                + " source coverage 必須逐一保留全部 configured discovery sources、不得重複，且達到最低可用數"
            )

        section_scopes = run.get("section_scopes")
        if is_latest_run:
            if not isinstance(section_scopes, list) or not section_scopes:
                errors.append(run_label + ".section_scopes 必須保存本輪板塊範圍")
                section_scopes = []
            scope_codes = []
            fallback_count = 0
            for scope_index, scope in enumerate(section_scopes, 1):
                scope_label = f"{run_label}.section_scopes[{scope_index}]"
                if not isinstance(scope, dict):
                    errors.append(scope_label + " 必須是物件")
                    continue
                code = scope.get("code")
                members = scope.get("member_country_codes")
                fallback = scope.get("fallback")
                if not isinstance(code, str) or len(code) != 3 or not code.isupper():
                    errors.append(scope_label + ".code 必須是三碼大寫代碼")
                else:
                    scope_codes.append(code)
                if (
                    not isinstance(members, list)
                    or any(not isinstance(member, str) or len(member) != 3 or not member.isupper() for member in members)
                    or len(members) != len(set(members))
                ):
                    errors.append(scope_label + ".member_country_codes 必須是唯一三碼代碼陣列")
                if not isinstance(fallback, bool):
                    errors.append(scope_label + ".fallback 必須是布林值")
                elif fallback:
                    fallback_count += 1
                    if members:
                        errors.append(scope_label + " fallback 板塊不得設定成員國")
                elif not members:
                    errors.append(scope_label + " 非 fallback 板塊必須設定成員國")
            if len(scope_codes) != len(set(scope_codes)):
                errors.append(run_label + ".section_scopes 板塊代碼不得重複")
            if fallback_count != 1:
                errors.append(run_label + ".section_scopes 必須恰有一個 fallback 板塊")
            coverage_by_id = {
                item.get("source_id"): item
                for item in coverage
                if isinstance(item, dict)
            }
            if (
                fallback_count == 1
                and primary_aggregator_ids
                and not any(
                    coverage_by_id.get(source_id, {}).get("scan_status") == "completed"
                    for source_id in primary_aggregator_ids
                )
            ):
                errors.append(
                    run_label
                    + " fallback/global 板塊要求至少一條 primary_aggregator discovery route 成功；"
                    "區域補充來源不得把全球 coverage 缺失洗成零事件"
                )

        raw_total = 0
        for source_index, item in enumerate(coverage, 1):
            label = f"{run_label}.source_coverage[{source_index}]"
            if not isinstance(item, dict):
                errors.append(label + " 必須是物件")
                continue
            unknown_fields = sorted(set(item) - SOURCE_COVERAGE_FIELDS)
            if unknown_fields:
                errors.append(label + " 含未知欄位：" + ", ".join(unknown_fields))
            within = item.get("within_window_count")
            ranked = item.get("ranked_count")
            selected = item.get("selected_for_pool_count")
            urls = item.get("selected_item_urls")
            ranked_items = item.get("ranked_items")
            scan_status = item.get("scan_status")
            coverage_complete = item.get("coverage_complete")
            coverage_status = item.get("coverage_status")
            if scan_status not in {"completed", "failed"}:
                errors.append(label + ".scan_status 必須是 completed 或 failed")
            if not isinstance(coverage_complete, bool):
                errors.append(label + ".coverage_complete 必須是布林值")
            if coverage_status not in {"complete", "degraded_partial", "degraded_cached", "unavailable"}:
                errors.append(label + ".coverage_status 無效")
            if coverage_complete is True and coverage_status != "complete":
                errors.append(label + " 完整 coverage 必須使用 coverage_status=complete")
            if coverage_complete is False and coverage_status == "complete":
                errors.append(label + " 不完整 coverage 不得使用 coverage_status=complete")
            for field in ("missing_segments", "missing_date_variants"):
                if not isinstance(item.get(field), list):
                    errors.append(label + f".{field} 必須是陣列")
            if scan_status == "failed":
                if coverage_complete is not False or coverage_status != "unavailable":
                    errors.append(label + " failed scan 必須明確標示 unavailable coverage")
                if any(item.get(field) not in (0, [], False, None) for field in (
                    "within_window_count", "ranked_count", "ranked_items",
                    "selected_for_pool_count", "selected_item_urls",
                    "discovery_ranking_completed", "scan_window_start",
                    "scan_window_end", "scan_evidence_path",
                )):
                    errors.append(label + " failed scan 不得保存偽造的掃描結果或證據")
                if not isinstance(item.get("failure_reason"), str) or not item["failure_reason"].strip():
                    errors.append(label + " failed scan 必須保存 failure_reason")
                continue
            if source_scan_evidence_required and is_latest_run:
                for field in ("scan_window_start", "scan_window_end", "scan_evidence_path"):
                    if not item.get(field):
                        errors.append(label + f" 缺少 {field}；不得自行宣告來源掃描完成")
                evidence_path = item.get("scan_evidence_path")
                if item.get("scan_window_start") != run.get("window_start") or item.get("scan_window_end") != run.get("window_end"):
                    errors.append(label + " 掃描證據時間窗必須與本輪精確24小時時間窗一致")
                if isinstance(evidence_path, str) and evidence_path:
                    local = Path(evidence_path.removeprefix("sandbox:"))
                    if not local.is_file():
                        errors.append(label + f" 掃描證據檔不存在：{evidence_path}")
                    else:
                        try:
                            scan = load(local)
                            errors.extend(validate_source_scan_evidence.validate_scan(
                                scan, item, source_by_id.get(item.get("source_id"), {}), label + ".scan_evidence"
                            ))
                        except (OSError, ValueError, json.JSONDecodeError) as error:
                            errors.append(label + f" 掃描證據無法讀取：{error}")
            if item.get("discovery_ranking_completed") is not True:
                errors.append(label + " 尚未完成 discovery priority 排序")
            ranking_method = item.get("discovery_ranking_method")
            if ranking_method != "discovery_priority_v1":
                errors.append(label + ".discovery_ranking_method 必須是 discovery_priority_v1")
            if not all(isinstance(value, int) and value >= 0 for value in (within, ranked, selected)):
                errors.append(label + " 來源數量欄位無效")
                continue
            if ranked != within:
                errors.append(label + " 必須評估時間窗內全部條目後再排序")
            if not isinstance(ranked_items, list) or len(ranked_items) != ranked:
                errors.append(label + " ranked_items 必須保存時間窗內完整排序清單")
                ranked_items = []
            ranked_urls = []
            scores = []
            for ranked_index, ranked_item in enumerate(ranked_items, 1):
                ranked_label = f"{label}.ranked_items[{ranked_index}]"
                if not isinstance(ranked_item, dict):
                    errors.append(ranked_label + " 必須是物件")
                    continue
                ranked_urls.append(ranked_item.get("url"))
                score = ranked_item.get("discovery_priority_score")
                scores.append(score)
                if not isinstance(score, (int, float)) or not 0 <= score <= 100:
                    errors.append(ranked_label + " discovery_priority_score 必須介於 0–100")
                if not isinstance(ranked_item.get("discovery_signals"), dict):
                    errors.append(ranked_label + " discovery_signals 必須是物件")
                if not isinstance(ranked_item.get("discovery_priority_reason"), str) or not ranked_item["discovery_priority_reason"].strip():
                    errors.append(ranked_label + " 缺少 discovery priority 理由")
            if len(set(ranked_urls)) != len(ranked_urls):
                errors.append(label + " ranked_items 含重複網址")
            if all(isinstance(score, (int, float)) for score in scores) and scores != sorted(scores, reverse=True):
                errors.append(label + " ranked_items 未按 discovery priority 由高至低排列")
            expected_urls = ranked_urls
            if selected != len(expected_urls):
                errors.append(label + " 入池數量必須等於完整排序清單")
            if not isinstance(urls, list) or len(urls) != selected or len(set(urls)) != len(urls):
                errors.append(label + " selected_item_urls 數量或唯一性不符")
            elif urls != expected_urls:
                errors.append(label + " 入池網址必須精確等於完整排序清單")
            raw_total += selected
        if run.get("raw_item_count") != raw_total:
            errors.append(run_label + ".raw_item_count 必須等於全部 discovery 來源入池數量總和")

        candidates = run.get("candidates", [])
        if run.get("deduplicated_candidate_count") != len(candidates):
            errors.append(run_label + ".deduplicated_candidate_count 必須等於去重候選筆數")
        if isinstance(run.get("raw_item_count"), int) and len(candidates) > run["raw_item_count"]:
            errors.append(run_label + " 去重後候選不得多於原始入池條目")

        if run_index == len(runs):
            processing_counts = run.get("processing_counts")
            count_fields = {
                "merged_article_row_count", "in_window_article_row_count",
                "canonical_url_count", "provisional_title_cluster_count",
                "semantic_event_count", "scored_event_count",
                "event_evidence_article_row_count", "non_news_article_row_count",
                "unresolved_article_row_count", "unresolved_exhausted_article_row_count",
                "c_or_higher_scored_event_count", "selected_event_count",
            }
            if not isinstance(processing_counts, dict) or set(processing_counts) != count_fields:
                errors.append(
                    run_label + ".processing_counts 必須包含完整文章、網址、分群、事件與評分階段計數"
                )
            elif any(
                not isinstance(processing_counts[field], int)
                or isinstance(processing_counts[field], bool)
                or processing_counts[field] < 0
                for field in count_fields
            ):
                errors.append(run_label + ".processing_counts 全部欄位必須是非負整數")
            else:
                dispositions = run.get("article_dispositions")
                disposition_counts = Counter(
                    item.get("disposition") for item in dispositions
                    if isinstance(dispositions, list) and isinstance(item, dict)
                ) if isinstance(dispositions, list) else Counter()
                expected_counts = {
                    "merged_article_row_count": run.get("raw_item_count"),
                    "in_window_article_row_count": run.get("raw_item_count"),
                    "semantic_event_count": len(candidates),
                    "scored_event_count": len(candidates),
                    "event_evidence_article_row_count": disposition_counts["event_evidence"],
                    "non_news_article_row_count": disposition_counts["non_news"],
                    "unresolved_article_row_count": disposition_counts["unresolved"],
                    "unresolved_exhausted_article_row_count": disposition_counts["unresolved_exhausted"],
                    "c_or_higher_scored_event_count": sum(
                        isinstance(item, dict)
                        and grade_meets_threshold(item.get("provisional_grade"), "C", ranking)
                        for item in candidates
                    ),
                    "selected_event_count": sum(
                        isinstance(item, dict) and item.get("decision") == "selected"
                        for item in candidates
                    ),
                }
                for field, expected in expected_counts.items():
                    if processing_counts[field] != expected:
                        errors.append(
                            run_label + f".processing_counts.{field} 必須等於可重算值 {expected}"
                        )
                ordered_fields = (
                    "in_window_article_row_count", "canonical_url_count",
                    "provisional_title_cluster_count", "semantic_event_count",
                )
                if any(
                    processing_counts[left] < processing_counts[right]
                    for left, right in zip(ordered_fields, ordered_fields[1:])
                ):
                    errors.append(
                        run_label + ".processing_counts 不得在去重或分群後反而增加"
                    )
                if (
                    processing_counts["event_evidence_article_row_count"]
                    + processing_counts["non_news_article_row_count"]
                    + processing_counts["unresolved_article_row_count"]
                    + processing_counts["unresolved_exhausted_article_row_count"]
                    != processing_counts["in_window_article_row_count"]
                ):
                    errors.append(
                        run_label + ".processing_counts 文章處置數總和必須等於時間窗內文章列數"
                    )

        semantic_event_ids = []
        candidate_by_event_id = {}
        if run_index == len(runs):
            narrative_identity_fields = {
                "who_or_what", "what_happened", "where", "when", "semantic_merge_basis"
            }
            structured_identity_fields = {
                "country_codes", "primary_country_code", "location_evidence",
                "event_occurred_at", "material_update_at", "material_update_type",
                "material_update_evidence",
            }
            identity_fields = narrative_identity_fields | structured_identity_fields
            try:
                run_window_start = parse_datetime(run.get("window_start", ""))
                run_window_end = parse_datetime(run.get("window_end", ""))
            except (TypeError, ValueError):
                run_window_start = run_window_end = None
            for candidate_index, candidate in enumerate(candidates, 1):
                label = f"{run_label}.candidates[{candidate_index}]"
                if not isinstance(candidate, dict):
                    continue
                semantic_event_id = candidate.get("semantic_event_id")
                if not isinstance(semantic_event_id, str) or not semantic_event_id.strip():
                    errors.append(label + ".semantic_event_id 必須是非空白語意事件識別碼")
                else:
                    semantic_event_ids.append(semantic_event_id)
                    candidate_by_event_id[semantic_event_id] = candidate
                identity = candidate.get("event_identity")
                if not isinstance(identity, dict) or not identity_fields.issubset(identity):
                    errors.append(
                        label + ".event_identity 必須包含事件主體、結構化地區、"
                        "事件發生時間、實質更新時間與合併依據"
                    )
                    continue
                text_fields = identity_fields - {"country_codes"}
                if any(
                    not isinstance(identity[field], str) or not identity[field].strip()
                    for field in text_fields
                ):
                    errors.append(label + ".event_identity 文字欄位都必須是非空白文字")

                country_codes = identity.get("country_codes")
                primary_country = identity.get("primary_country_code")
                if (
                    not isinstance(country_codes, list)
                    or not country_codes
                    or any(
                        not isinstance(code, str) or len(code) != 3 or not code.isupper()
                        for code in country_codes
                    )
                    or len(country_codes) != len(set(country_codes))
                ):
                    errors.append(label + ".event_identity.country_codes 必須是唯一三碼大寫代碼陣列")
                elif primary_country not in country_codes:
                    errors.append(label + ".event_identity.primary_country_code 必須列在 country_codes")

                expected_section = None
                fallback_codes = []
                for scope in section_scopes if isinstance(section_scopes, list) else []:
                    if not isinstance(scope, dict):
                        continue
                    if scope.get("fallback") is True:
                        fallback_codes.append(scope.get("code"))
                        continue
                    members = scope.get("member_country_codes")
                    if (
                        expected_section is None
                        and isinstance(members, list)
                        and isinstance(country_codes, list)
                        and set(country_codes) & set(members)
                    ):
                        expected_section = scope.get("code")
                if expected_section is None and len(fallback_codes) == 1:
                    expected_section = fallback_codes[0]
                if expected_section is not None and candidate.get("section") != expected_section:
                    errors.append(
                        label + f".section 必須由 event_identity.country_codes 對照 "
                        f"section_scopes 推導為 {expected_section}；來源分桶不得參與"
                    )

                update_type = identity.get("material_update_type")
                if update_type not in MATERIAL_UPDATE_TYPES:
                    errors.append(label + ".event_identity.material_update_type 不是允許的實質更新類型")
                try:
                    occurred_at = parse_datetime(identity.get("event_occurred_at", ""))
                    material_update_at = parse_datetime(identity.get("material_update_at", ""))
                except (TypeError, ValueError):
                    errors.append(label + ".event_identity 事件與更新時間必須是含時區的 ISO 時間")
                    continue
                if occurred_at > material_update_at:
                    errors.append(label + ".event_identity.event_occurred_at 不得晚於 material_update_at")
                if (
                    run_window_start is not None
                    and not (run_window_start < material_update_at <= run_window_end)
                ):
                    errors.append(label + ".event_identity.material_update_at 必須落在精確執行時間窗內")
                occurred_in_window = (
                    run_window_start is not None
                    and run_window_start < occurred_at <= run_window_end
                )
                if update_type == "new_event" and not occurred_in_window:
                    errors.append(label + ".event_identity 舊事件不得以 new_event 或今日重整冒充新事件")
                if (
                    not occurred_in_window
                    and update_type != "new_event"
                    and candidate.get("continuity", {}).get("status") == "new"
                ):
                    errors.append(label + ".continuity.status 舊事件的實質更新必須標為 continuing")

                temporal_review = identity.get("temporal_review")
                temporal_fields = {
                    "review_method", "window_status", "active_during_window",
                    "new_or_changed_facts", "repeated_old_facts",
                    "current_window_impact", "comparison_evidence",
                }
                if (
                    not isinstance(temporal_review, dict)
                    or not temporal_fields.issubset(temporal_review)
                    or temporal_review.get("review_method") != "model_content_comparison"
                ):
                    errors.append(
                        label + ".event_identity.temporal_review 必須由模型比較事件內容、"
                        "既有時間線與本輪事實"
                    )
                    continue
                for field in (
                    "new_or_changed_facts", "repeated_old_facts", "current_window_impact"
                ):
                    value = temporal_review.get(field)
                    if not isinstance(value, list) or any(
                        not isinstance(item, str) or not item.strip() for item in value
                    ):
                        errors.append(label + f".event_identity.temporal_review.{field} 必須是文字陣列")
                if not isinstance(temporal_review.get("comparison_evidence"), str) or not temporal_review["comparison_evidence"].strip():
                    errors.append(label + ".event_identity.temporal_review.comparison_evidence 不得為空")

                window_status = temporal_review.get("window_status")
                new_facts = temporal_review.get("new_or_changed_facts", [])
                current_impact = temporal_review.get("current_window_impact", [])
                active_during_window = temporal_review.get("active_during_window")
                if window_status == "old_restatement":
                    errors.append(label + ".event_identity.temporal_review old_restatement 不得成為語意事件候選；文章應記為 non_news")
                elif window_status == "new_event":
                    if update_type != "new_event" or not occurred_in_window or not new_facts:
                        errors.append(label + ".event_identity.temporal_review new_event 必須列出窗內首次發生的事實")
                elif window_status == "material_update":
                    if update_type in {"new_event", "ongoing_verified_current_impact"} or not new_facts:
                        errors.append(label + ".event_identity.temporal_review material_update 必須列出本輪新增或變更事實")
                elif window_status == "ongoing_current_impact":
                    if (
                        update_type != "ongoing_verified_current_impact"
                        or active_during_window is not True
                        or not current_impact
                    ):
                        errors.append(label + ".event_identity.temporal_review ongoing_current_impact 必須證明事件在窗內仍持續造成影響")
                else:
                    errors.append(label + ".event_identity.temporal_review.window_status 無效")
            if len(semantic_event_ids) != len(set(semantic_event_ids)):
                errors.append(run_label + ".semantic_event_id 不得由兩個候選重複使用")

            dispositions = run.get("article_dispositions")
            expected_rows = Counter(
                (item.get("source_id"), url)
                for item in coverage if isinstance(item, dict)
                for url in item.get("selected_item_urls", [])
            )
            actual_rows = Counter()
            mapped_event_ids = set()
            if not isinstance(dispositions, list):
                errors.append(run_label + ".article_dispositions 必須逐列保存文章處置")
                dispositions = []
            for disposition_index, disposition in enumerate(dispositions, 1):
                label = f"{run_label}.article_dispositions[{disposition_index}]"
                if not isinstance(disposition, dict):
                    errors.append(label + " 必須是物件")
                    continue
                source_id = disposition.get("source_id")
                url = disposition.get("url")
                outcome = disposition.get("disposition")
                semantic_event_id = disposition.get("semantic_event_id")
                reason = disposition.get("reason")
                actual_rows[(source_id, url)] += 1
                if not isinstance(reason, str) or not reason.strip():
                    errors.append(label + ".reason 不得為空")
                if outcome == "event_evidence":
                    candidate = candidate_by_event_id.get(semantic_event_id)
                    if candidate is None:
                        errors.append(label + ".semantic_event_id 必須指向一個語意事件候選")
                    elif url not in candidate.get("candidate_urls", []):
                        errors.append(label + " 網址必須列在所指語意事件的 candidate_urls")
                    else:
                        mapped_event_ids.add(semantic_event_id)
                elif outcome == "non_news":
                    if semantic_event_id is not None:
                        errors.append(label + " non_news 不得指向語意事件")
                elif outcome == "unresolved":
                    errors.append(label + " unresolved 文章不得通過完成驗收")
                elif outcome == "unresolved_exhausted":
                    if semantic_event_id is not None:
                        errors.append(label + " unresolved_exhausted 不得指向語意事件")
                else:
                    errors.append(label + ".disposition 無效")
            if actual_rows != expected_rows:
                errors.append(run_label + ".article_dispositions 必須與來源文章列逐筆完全一致")
            if set(semantic_event_ids) - mapped_event_ids:
                errors.append(run_label + " 每個語意事件都必須至少有一筆 event_evidence")

        valid_source_ids = all_configured_source_ids or set(coverage_ids)
        candidate_url_list = []
        historical_compact_run = False
        for candidate_index, candidate in enumerate(candidates, 1):
            label = f"{run_label}.candidates[{candidate_index}]"
            if not is_latest_run and is_compact_historical_candidate(candidate):
                historical_compact_run = True
                errors.extend(validate_compact_historical_candidate(
                    candidate, ranking, valid_source_ids, label
                ))
                continue
            grade = candidate.get("provisional_grade")
            decision = candidate.get("decision")
            reason_code = candidate.get("reason_code")
            if reason_code not in REASON_CODES:
                errors.append(label + " reason_code 無效")
            if not isinstance(candidate.get("grade_reason"), str) or not candidate["grade_reason"].strip():
                errors.append(label + " 缺少 SS–E 評級理由")
            elif candidate["grade_reason"].strip() in TEMPLATE_GRADE_REASONS:
                errors.append(label + " grade_reason 使用禁止的模板理由，必須寫出事件特有的影響與本期增量")
            grading = candidate.get("grading_evidence")
            if not isinstance(grading, dict):
                errors.append(label + " 缺少結構化 grading_evidence；不得只填 grade_reason")
                grading = {}
            required_grading = {
                "impact_scope_level", "direct_consequences", "structural_significance",
                "window_material_changes", "border_conflict_review", "ongoing_conflict_review",
            }
            if run_index == len(runs):
                required_grading.update({"local_disaster_review", "policy_governance_review"})
            missing_grading = sorted(required_grading - set(grading))
            if missing_grading:
                errors.append(label + " grading_evidence 缺少：" + ", ".join(missing_grading))
            if grading.get("impact_scope_level") not in {
                "facility", "local", "subregional", "national", "multinational", "global"
            }:
                errors.append(label + " impact_scope_level 無效")
            for field in ("direct_consequences", "window_material_changes"):
                value = grading.get(field)
                if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
                    errors.append(label + f" {field} 必須是具體文字陣列")
            for field in ("structural_significance",):
                if not isinstance(grading.get(field), str) or not grading[field].strip():
                    errors.append(label + f" {field} 不得為空")

            if run_index == len(runs):
                importance_score = candidate.get("importance_score")
                errors.extend(validate_v2_candidate(candidate, ranking, label))
                errors.extend(validate_policy_governance_review(
                    grading.get("policy_governance_review"), importance_score, label,
                    candidate.get("policy_stage"), ranking
                ))

            border = grading.get("border_conflict_review")
            if not isinstance(border, dict):
                errors.append(label + " 缺少 border_conflict_review")
                border = {}
            if not isinstance(border.get("applies"), bool):
                errors.append(label + " border_conflict_review.applies 必須是布林值")
            border_keys = {
                "is_border_conflict", "formal_war", "de_facto_war_scale",
                "related_to_monitored_section", "user_weight_elevated",
                "exception_reason",
            }
            if border.get("applies") is True and border_keys - set(border):
                errors.append(label + " border_conflict_review 欄位不完整")

            ongoing = grading.get("ongoing_conflict_review")
            if not isinstance(ongoing, dict):
                errors.append(label + " 缺少 ongoing_conflict_review")
                ongoing = {}
            if not isinstance(ongoing.get("applies"), bool):
                errors.append(label + " ongoing_conflict_review.applies 必須是布林值")
            ongoing_keys = {
                "is_ongoing_conflict", "same_conflict_as_history", "routine_incident",
                "material_change", "change_types", "reversal_or_escalation_possible",
                "external_system_impact", "continuity_discount_applied", "exception_reason",
            }
            if ongoing.get("applies") is True and ongoing_keys - set(ongoing):
                errors.append(label + " ongoing_conflict_review 欄位不完整")
            local_disaster = grading.get("local_disaster_review")
            if run_index == len(runs):
                if not isinstance(local_disaster, dict):
                    errors.append(label + " 最新一輪缺少 local_disaster_review")
                    local_disaster = {}
                applies = local_disaster.get("applies")
                if not isinstance(applies, bool):
                    errors.append(label + " local_disaster_review.applies 必須是布林值")
                elif applies:
                    required_local = {
                        "confirmed_deaths", "special_significance_triggers",
                        "grade_adjustment_reason",
                    }
                    missing_local = sorted(required_local - set(local_disaster))
                    if missing_local:
                        errors.append(
                            label + " local_disaster_review 缺少：" + ", ".join(missing_local)
                        )
                    deaths = local_disaster.get("confirmed_deaths")
                    triggers = local_disaster.get("special_significance_triggers")
                    reason = local_disaster.get("grade_adjustment_reason")
                    if not isinstance(deaths, int) or isinstance(deaths, bool) or deaths < 0:
                        errors.append(label + " confirmed_deaths 必須是零以上的保守確認值")
                    elif isinstance(candidate.get("importance_breakdown"), dict):
                        importance = candidate["importance_breakdown"]
                        public_impact = importance.get("public_impact")
                        death_floor = public_impact_floor_from_confirmed_deaths(deaths, ranking)
                        if (
                            isinstance(public_impact, (int, float))
                            and not isinstance(public_impact, bool)
                            and public_impact < death_floor
                        ):
                            errors.append(
                                label + f" {deaths} 人保守確認死亡的 public_impact "
                                f"死亡證據最低為 {death_floor} 分"
                            )
                    if not isinstance(triggers, list):
                        errors.append(label + " special_significance_triggers 必須是陣列")
                        triggers = []
                    else:
                        invalid_triggers = [
                            trigger for trigger in triggers
                            if not isinstance(trigger, str)
                            or trigger not in LOCAL_DISASTER_SPECIAL_TRIGGERS
                        ]
                        if invalid_triggers:
                            errors.append(
                                label + " special_significance_triggers 無效："
                                + ", ".join(map(str, invalid_triggers))
                            )
                        if (
                            all(isinstance(trigger, str) for trigger in triggers)
                            and len(triggers) != len(set(triggers))
                        ):
                            errors.append(label + " special_significance_triggers 不得重複")
                    if (
                        border.get("is_border_conflict") is True
                        or ongoing.get("is_ongoing_conflict") is True
                    ):
                        errors.append(label + " 已屬軍事／衝突規則的事件不得同時套用地方災害審查")
                    if triggers and (not isinstance(reason, str) or not reason.strip()):
                        errors.append(label + " 記錄特殊意義證據時必須填寫具體調整理由")
            if GRADE_ORDER.get(grade, -1) >= GRADE_ORDER["B-"] and not grading.get("direct_consequences"):
                errors.append(label + " B- 以上必須列出至少一項已發生的直接公共後果")
            source_ids = candidate.get("source_ids")
            candidate_urls = candidate.get("candidate_urls")
            if not isinstance(candidate_urls, list) or not candidate_urls:
                errors.append(label + " 缺少原始入池網址")
            else:
                candidate_url_list.extend(candidate_urls)
            if not isinstance(source_ids, list) or not source_ids:
                errors.append(label + " 缺少來源池追溯")
            elif any(source_id not in valid_source_ids for source_id in source_ids):
                errors.append(label + " 引用未定義的 discovery 來源")

            if grade_meets_threshold(grade, "C", ranking) and decision not in {"selected", "merged"}:
                errors.append(label + " C 以上必須入選；禁止篇數上限、相對淘汰或延後")
            if grade_meets_threshold(grade, "C", ranking) and (
                not isinstance(candidate.get("selected_event_id"), str)
                or not candidate["selected_event_id"].strip()
            ):
                errors.append(label + " C 以上候選必須以 selected_event_id 映射至讀者版事件")
            if grade == "C-":
                if decision not in {"deferred", "merged"} or reason_code not in {"c_minus_reserve", "duplicate_merged"}:
                    errors.append(label + " C- 只能進候補池，不得入選")
            if not grade_meets_threshold(grade, "C", ranking) and decision == "selected":
                errors.append(label + " C-／D／E 不得入選")
            if candidate.get("source_audit", {}).get("reliable_source_count") == 1 and reason_code == "unreliable_or_unverified":
                errors.append(label + " 已有一個可靠來源，不得僅以來源不足排除")
        pool_urls = [
            url for item in coverage if isinstance(item, dict)
            for url in item.get("selected_item_urls", [])
        ]
        if len(candidate_url_list) != len(set(candidate_url_list)):
            errors.append(run_label + " 去重候選之間重複占用同一原始網址")
        if run_index == len(runs) and isinstance(run.get("article_dispositions"), list):
            event_urls = {
                item.get("url") for item in run["article_dispositions"]
                if isinstance(item, dict) and item.get("disposition") == "event_evidence"
            }
            if set(candidate_url_list) != event_urls:
                errors.append(run_label + " candidate_urls 必須精確等於 event_evidence 網址")
        elif not historical_compact_run and set(candidate_url_list) != set(pool_urls):
            errors.append(run_label + " 每個 discovery 來源入池網址都必須歸屬一個去重候選，禁止候選無聲消失")
    if require_fourteen_day_complete:
        errors += fourteen_day_completeness_errors(data)
    return errors


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="cmd", required=True)
    append_parser = subparsers.add_parser("append")
    append_parser.add_argument("--history", required=True)
    append_parser.add_argument("--run", required=True)
    append_parser.add_argument("--output", required=True)
    append_parser.add_argument("--source-pool", required=True)
    append_parser.add_argument("--retention-days", type=int, default=14)
    validate_parser = subparsers.add_parser("validate")
    validate_parser.add_argument("--input", required=True)
    validate_parser.add_argument("--source-pool", required=True)
    validate_parser.add_argument("--require-fourteen-day-complete", action="store_true")
    args = parser.parse_args()
    try:
        source_pool = load(args.source_pool)
        if args.cmd == "validate":
            errors = validate(
                load(args.input), source_pool,
                require_fourteen_day_complete=args.require_fourteen_day_complete,
            )
            for error in errors:
                print("FAIL:", error)
            if not errors:
                print("OK")
            return int(bool(errors))

        history = load(args.history) if Path(args.history).exists() else {"runs": []}
        current_run = load(args.run)
        cutoff = parse_datetime(current_run["generated_at"]) - timedelta(days=args.retention_days)
        runs = [
            item for item in history.get("runs", [])
            if parse_datetime(item["generated_at"]) >= cutoff
            and item.get("run_id") != current_run.get("run_id")
        ] + [current_run]
        runs.sort(key=lambda item: parse_datetime(item["generated_at"]))
        output = {
            "schema_version": "1.2.0",
            "retention_days": args.retention_days,
            "updated_at": parse_datetime(current_run["generated_at"]).isoformat(),
            "runs": runs,
        }
        errors = validate(output, source_pool)
        if errors:
            raise ValueError("；".join(errors))
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("OK")
        return 0
    except Exception as error:
        print("FAIL:", error)
        return 1


if __name__ == "__main__":
    sys.exit(main())
